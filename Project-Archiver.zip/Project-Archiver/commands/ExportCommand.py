# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Copyright (c) 2020 by Patrick Rainsberry.                                   ~
#  :license: Apache2, see LICENSE for more details.                            ~
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  SampleCommand2.py                                                           ~
#  This file is a component of Project-Archiver.                               ~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import os
import unicodedata
import re

import adsk.core
import adsk.fusion
import adsk.cam

import apper
from apper import AppObjects

import config
import datetime
import json

SKIPPED_FILES = []


def export_folder(root_folder, output_folder, file_types, write_version, name_option, folder_preserve, start_file=None):
    ao = AppObjects()
    
    all_files = [file for file in root_folder.dataFiles if file.fileExtension == "f3d"]
    
    for i, file in enumerate(all_files):
        if start_file and file.name != start_file:
            continue
        start_file = None  # Reset start_file after finding it
        
        next_file = all_files[i+1].name if i+1 < len(all_files) else "COMPLETED"
        save_progress(file.name, next_file)
        
        open_doc(file)
        try:
            output_name = get_name(write_version, name_option)
            export_active_doc(output_folder, file_types, output_name)
        except ValueError as e:
            ao.ui.messageBox(str(e))
        except AttributeError as e:
            ao.ui.messageBox(str(e))
            break
        
        ao.app.activeDocument.close(False)

    for folder in root_folder.dataFolders:
        if folder_preserve:
            new_folder = os.path.join(output_folder, folder.name, "")
            if not os.path.exists(new_folder):
                os.makedirs(new_folder)
        else:
            new_folder = output_folder
        
        export_folder(folder, new_folder, file_types, write_version, name_option, folder_preserve, start_file)

def open_doc(data_file):
    app = adsk.core.Application.get()

    try:
        document = app.documents.open(data_file, True)
        if document is not None:
            document.activate()
    except:
        pass
        # TODO add handling


def export_active_doc(folder, file_types, output_name):
    global SKIPPED_FILES

    ao = AppObjects()
    export_mgr = ao.export_manager

    export_functions = [export_mgr.createIGESExportOptions,
                        export_mgr.createSTEPExportOptions,
                        export_mgr.createSATExportOptions,
                        export_mgr.createSMTExportOptions,
                        export_mgr.createFusionArchiveExportOptions,
                        export_mgr.createSTLExportOptions]
    export_extensions = ['.igs', '.step', '.sat', '.smt', '.f3d', '.stl']

    for i in range(file_types.count-2):

        if file_types.item(i).isSelected:
            export_name = folder + output_name + export_extensions[i]
            export_name = dup_check(export_name)
            export_options = export_functions[i](export_name)
            export_mgr.execute(export_options)

    if file_types.item(file_types.count - 2).isSelected:

        if ao.document.allDocumentReferences.count > 0:
            SKIPPED_FILES.append(ao.document.name)

        else:
            export_name = folder + output_name + '.f3d'
            export_name = dup_check(export_name)
            export_options = export_mgr.createFusionArchiveExportOptions(export_name)
            export_mgr.execute(export_options)

    if file_types.item(file_types.count - 1).isSelected:
        # Check if document contains any solid bodies
        design = adsk.fusion.Design.cast(ao.product)
        if design is not None:
            root_comp = design.rootComponent
            if root_comp.bRepBodies.count == 0:
                # Skip this document if it contains no solid bodies
                SKIPPED_FILES.append(ao.document.name)
            else:
                stl_export_name = folder + output_name + '.stl'
                stl_options = export_mgr.createSTLExportOptions(ao.design.rootComponent, stl_export_name)
                export_mgr.execute(stl_options)


def dup_check(name):
    if os.path.exists(name):
        base, ext = os.path.splitext(name)
        base += '-dup'
        name = base + ext
        dup_check(name)
    return name


def get_name(write_version, option):
    ao = AppObjects()
    output_name = ''

    if option == 'Document Name':

        doc_name = ao.app.activeDocument.name

        if not write_version:
            doc_name = doc_name[:doc_name.rfind(' v')]
        output_name = doc_name

    elif option == 'Description':
        output_name = ao.root_comp.description

    elif option == 'Part Number':
        output_name = ao.root_comp.partNumber

    else:
        raise ValueError('Something strange happened')

    # replace invalid characters in filename
    output_name = slugify(output_name)
        
    return output_name

# Inspired by https://stackoverflow.com/questions/295135/turn-a-string-into-a-valid-filename
def slugify(value, allow_unicode=False):
    """
    Taken from https://github.com/django/django/blob/master/django/utils/text.py
    Convert to ASCII if 'allow_unicode' is False. Convert spaces or repeated
    dashes to single dashes. Remove characters that aren't alphanumerics,
    underscores, or hyphens. Convert to lowercase. Also strip leading and
    trailing whitespace, dashes, and underscores.
    """
    value = str(value)
    if allow_unicode:
        value = unicodedata.normalize('NFKC', value)
    else:
        value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value)
    return re.sub(r'[-\s]+', '-', value).strip('-_')

def update_name_inputs(command_inputs, selection):
    command_inputs.itemById('write_version').isVisible = False

    if selection == 'Document Name':
        command_inputs.itemById('write_version').isVisible = True


class ExportCommand(apper.Fusion360CommandBase):
    

    def on_input_changed(self, command: adsk.core.Command, inputs: adsk.core.CommandInputs,
                         changed_input, input_values):
        if changed_input.id == 'name_option_id':
            update_name_inputs(inputs, changed_input.selectedItem.name)

    def on_execute(self, command: adsk.core.Command, inputs: adsk.core.CommandInputs, args, input_values):
        global SKIPPED_FILES
        ao = AppObjects()

        output_folder = input_values['output_folder']
        folder_preserve = input_values['folder_preserve_id']
        file_types = inputs.itemById('file_types_input').listItems
        write_version = input_values['write_version']
        name_option = input_values['name_option_id']
        root_folder = ao.app.data.activeProject.rootFolder
        
        if not output_folder.endswith(os.path.sep):
            output_folder += os.path.sep

        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        start_file, _ = load_progress()
        export_folder(root_folder, output_folder, file_types, write_version, name_option, folder_preserve, start_file)

        if len(SKIPPED_FILES) > 0:
            ao.ui.messageBox(
                "The following files contained external references and could not be exported as f3d's: {}".format(
                    SKIPPED_FILES
                )
            )
            
        ao.ui.messageBox(
                "This File Exporter Is COMPLETED!"
            )

        close_command = ao.ui.commandDefinitions.itemById(self.fusion_app.command_id_from_name(config.close_cmd_id))
        close_command.execute()

    def on_create(self, command: adsk.core.Command, inputs: adsk.core.CommandInputs):
        global SKIPPED_FILES
        SKIPPED_FILES.clear()
        #default_dir = apper.get_default_dir(config.app_name)
        default_dir = 'D:\ProjectArchive3'

        inputs.addStringValueInput('output_folder', 'Output Folder:', default_dir)

        drop_input_list = inputs.addDropDownCommandInput('file_types_input', 'Export Types',
                                                         adsk.core.DropDownStyles.CheckBoxDropDownStyle)
        drop_input_list = drop_input_list.listItems
        drop_input_list.add('IGES', False)
        drop_input_list.add('STEP', False)
        drop_input_list.add('SAT', False)
        drop_input_list.add('SMT', False)
        drop_input_list.add('F3D', True)
        drop_input_list.add('STL', False)

        name_option_group = inputs.addDropDownCommandInput('name_option_id', 'File Name Option',
                                                                   adsk.core.DropDownStyles.TextListDropDownStyle)
        name_option_group.listItems.add('Document Name', True)
        name_option_group.listItems.add('Description', False)
        name_option_group.listItems.add('Part Number', False)
        name_option_group.isVisible = True

        preserve_input = inputs.addBoolValueInput('folder_preserve_id', 'Preserve folder structure?', True, '', True)
        preserve_input.isVisible = True

        version_input = inputs.addBoolValueInput('write_version', 'Write versions to output file names?', True, '', False)
        version_input.isVisible = False

        update_name_inputs(inputs, 'Document Name')


def load_progress():
    progress_file = os.path.join('D:\ProjectArchive3', 'export_progress.txt')
    try:
        with open(progress_file, 'r') as f:
            lines = f.readlines()
            current_file = lines[0].strip()
            next_file = lines[1].strip() if len(lines) > 1 else None
            return current_file, next_file
    except FileNotFoundError:
        return None, None
    
def save_progress(current_file, next_file):
    progress_file = os.path.join('D:\\ProjectArchive3\\', 'export_progress.txt')
    with open(progress_file, 'w') as f:
        f.write(f"{current_file}\n{next_file}")
        f.flush()
        os.fsync(f.fileno())

    # Create documentation file with file tree
    doc_file = os.path.join('D:\\ProjectArchive3\\', 'export_documentation.txt')
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def generate_tree(path, prefix=''):
        tree = []
        contents = sorted(os.listdir(path))
        for i, item in enumerate(contents):
            item_path = os.path.join(path, item)
            if os.path.isdir(item_path):
                if i == len(contents) - 1:
                    tree.append(f"{prefix}└── {item}/")
                    tree.extend(generate_tree(item_path, prefix + '    '))
                else:
                    tree.append(f"{prefix}├── {item}/")
                    tree.extend(generate_tree(item_path, prefix + '│   '))
            else:
                if i == len(contents) - 1:
                    tree.append(f"{prefix}└── {item}")
                else:
                    tree.append(f"{prefix}├── {item}")
        return tree

    with open(doc_file, 'a', encoding="utf-8") as f:
        f.write(f"\n{timestamp} - Current: {current_file}, Next: {next_file}\n")
        f.write("File Tree:\n")
        tree = generate_tree('D:\\ProjectArchive3\\')
        f.write('\n'.join(tree))
        f.write('\n\n')